import React from 'react';
import './FavoriteButton.css';

export default class FavoritePokemon extends React.Component{
    state = {

        btnType: 'btn btn-primary',
        btnName: 'Not Favorite'
    }
    
    addtoFavorite = () => {
        if(this.state.btnType === 'btn btn-primary'){
            this.setState({
                btnType: 'btn btn-warning',
                btnName: 'Favorite'
            });
            localStorage.setItem(0, 'Red');
            
        }else{
            this.setState({
                btnType: 'btn btn-primary',
                btnName: 'Not Favorite'
            });
            localStorage.removeItem(0, 'Red')
        }
    }

    render(){
    return <button id = "btn" onClick = {this.addtoFavorite} > {this.state.btnName} </button>
    }
}