import React from 'react'
import { Layout } from '../layout/Layout'

export const Favorites = () => {
    return (
        <Layout>
            <h1>Favorites</h1>
        </Layout>
    )
}
